package com.gesturemacro.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * A recorded custom gesture: every finger that touched the screen is one Stroke.
 * Several strokes together are one "multiple-touch gesture", exactly like
 * AssistiveTouch's "A sequence of gestures will be combined into one multiple-touch gesture".
 */
public class Macro {
    public String id;
    public String name;
    /** Real screen size (pixels) at the time of recording. */
    public int screenW;
    public int screenH;
    public long durationMs;
    public List<Stroke> strokes = new ArrayList<>();

    public static class Stroke {
        public long startMs;
        public long endMs;
        /** Each point is {x, y, tMs}; x/y are screen pixels, t is ms since the first touch. */
        public List<float[]> pts = new ArrayList<>();
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("w", screenW);
        o.put("h", screenH);
        o.put("d", durationMs);
        JSONArray sa = new JSONArray();
        for (Stroke s : strokes) {
            JSONArray pa = new JSONArray();
            for (float[] p : s.pts) {
                JSONArray q = new JSONArray();
                q.put(Math.round(p[0]));
                q.put(Math.round(p[1]));
                q.put(Math.round(p[2]));
                pa.put(q);
            }
            sa.put(pa);
        }
        o.put("s", sa);
        return o;
    }

    public static Macro fromJson(JSONObject o) throws JSONException {
        Macro m = new Macro();
        m.id = o.getString("id");
        m.name = o.getString("name");
        m.screenW = o.getInt("w");
        m.screenH = o.getInt("h");
        m.durationMs = o.getLong("d");
        JSONArray sa = o.getJSONArray("s");
        for (int i = 0; i < sa.length(); i++) {
            JSONArray pa = sa.getJSONArray(i);
            Stroke s = new Stroke();
            for (int j = 0; j < pa.length(); j++) {
                JSONArray q = pa.getJSONArray(j);
                s.pts.add(new float[]{(float) q.getDouble(0), (float) q.getDouble(1), (float) q.getDouble(2)});
            }
            if (s.pts.isEmpty()) continue;
            s.startMs = (long) s.pts.get(0)[2];
            s.endMs = (long) s.pts.get(s.pts.size() - 1)[2];
            m.strokes.add(s);
        }
        return m;
    }
}
