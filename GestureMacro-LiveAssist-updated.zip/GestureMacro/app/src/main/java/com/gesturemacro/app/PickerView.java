package com.gesturemacro.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

/**
 * Full-screen helper used by the menu items "Long Press", "Double Tap", "Hold and Drag" and
 * "Pinch and Rotate": you show it where to act, then the service performs the gesture there.
 */
public class PickerView extends View {
    public interface Callback {
        /** longpress / doubletap: {x, y}.  holddrag: {x,y,t, x,y,t, ...}.  pinch: {a0x,a0y,b0x,b0y,a1x,a1y,b1x,b1y}. */
        void onDone(float[] data);

        void onCancel();
    }

    public static final String LONGPRESS = "longpress", DOUBLETAP = "doubletap",
            HOLDDRAG = "holddrag", PINCH = "pinch";

    private final String mode;
    private final Callback cb;
    private final float d;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF cancelRect = new RectF();

    private float curX, curY;
    private boolean down;
    private long t0;
    private final ArrayList<float[]> path = new ArrayList<>();

    // pinch state
    private float cx = -1, cy = -1;
    private final float r0;
    private float ax, ay, bx, by;      // current circles
    private float a0x, a0y, b0x, b0y;  // starting circles
    private int dragging = -1;
    private boolean pinchMoved;

    public PickerView(Context c, String mode, Callback cb) {
        super(c);
        this.mode = mode;
        this.cb = cb;
        d = c.getResources().getDisplayMetrics().density;
        r0 = 90f * d;
    }

    private String hint() {
        switch (mode) {
            case LONGPRESS: return "Touch where you want to Long Press";
            case DOUBLETAP: return "Touch where you want to Double Tap";
            case HOLDDRAG: return "Touch and drag: the finger will hold, then drag";
            default: return "Drag a circle to pinch or rotate. Touch elsewhere to move the circles";
        }
    }

    private void layoutPinch() {
        ax = cx - r0;
        ay = cy;
        bx = cx + r0;
        by = cy;
    }

    @Override
    protected void onDraw(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x33000000);
        c.drawRect(0, 0, getWidth(), getHeight(), paint);

        // hint + cancel pill
        paint.setColor(0xFFFFFFFF);
        paint.setTextSize(15f * d);
        paint.setTextAlign(Paint.Align.CENTER);
        c.drawText(hint(), getWidth() / 2f, 96f * d, paint);

        float pw = 110f * d, ph = 40f * d;
        cancelRect.set(getWidth() / 2f - pw / 2f, 24f * d, getWidth() / 2f + pw / 2f, 24f * d + ph);
        paint.setColor(0xCC1C1C1E);
        c.drawRoundRect(cancelRect, ph / 2f, ph / 2f, paint);
        paint.setColor(0xFF0A84FF);
        paint.setTextSize(16f * d);
        c.drawText("Cancel", cancelRect.centerX(), cancelRect.centerY() + 6f * d, paint);

        if (mode.equals(PINCH)) {
            if (cx < 0) {
                cx = getWidth() / 2f;
                cy = getHeight() / 2f;
                layoutPinch();
            }
            drawCircle(c, ax, ay);
            drawCircle(c, bx, by);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f * d);
            paint.setColor(0x88FFFFFF);
            c.drawLine(ax, ay, bx, by, paint);
        } else if (down) {
            drawCircle(c, curX, curY);
        }
    }

    private void drawCircle(Canvas c, float x, float y) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x55FFFFFF);
        c.drawCircle(x, y, 30f * d, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f * d);
        paint.setColor(0xFFFFFFFF);
        c.drawCircle(x, y, 30f * d, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        float x = e.getX();
        float y = e.getY();
        float sx = x + loc[0];
        float sy = y + loc[1];
        int a = e.getActionMasked();

        if (a == MotionEvent.ACTION_DOWN && cancelRect.contains(x, y)) {
            cb.onCancel();
            return true;
        }

        if (mode.equals(PINCH)) {
            switch (a) {
                case MotionEvent.ACTION_DOWN:
                    pinchMoved = false;
                    if (Math.hypot(x - ax, y - ay) < 60f * d) dragging = 0;
                    else if (Math.hypot(x - bx, y - by) < 60f * d) dragging = 1;
                    else {
                        dragging = -1;
                        cx = x;
                        cy = y;
                        layoutPinch();
                    }
                    a0x = ax; a0y = ay; b0x = bx; b0y = by;
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (dragging == 0) {
                        ax = x; ay = y; bx = 2 * cx - x; by = 2 * cy - y;
                        pinchMoved = true;
                    } else if (dragging == 1) {
                        bx = x; by = y; ax = 2 * cx - x; ay = 2 * cy - y;
                        pinchMoved = true;
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    if (dragging >= 0 && pinchMoved) {
                        cb.onDone(new float[]{
                                a0x + loc[0], a0y + loc[1], b0x + loc[0], b0y + loc[1],
                                ax + loc[0], ay + loc[1], bx + loc[0], by + loc[1]});
                        return true;
                    }
                    break;
                default:
                    break;
            }
            invalidate();
            return true;
        }

        switch (a) {
            case MotionEvent.ACTION_DOWN:
                down = true;
                t0 = e.getEventTime();
                path.clear();
                path.add(new float[]{sx, sy, 0});
                break;
            case MotionEvent.ACTION_MOVE:
                path.add(new float[]{sx, sy, e.getEventTime() - t0});
                break;
            case MotionEvent.ACTION_UP: {
                down = false;
                path.add(new float[]{sx, sy, e.getEventTime() - t0});
                if (mode.equals(HOLDDRAG)) {
                    float[] out = new float[path.size() * 3];
                    for (int i = 0; i < path.size(); i++) {
                        out[i * 3] = path.get(i)[0];
                        out[i * 3 + 1] = path.get(i)[1];
                        out[i * 3 + 2] = path.get(i)[2];
                    }
                    cb.onDone(out);
                } else {
                    cb.onDone(new float[]{sx, sy});
                }
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                down = false;
                break;
            default:
                break;
        }
        curX = x;
        curY = y;
        invalidate();
        return true;
    }
}
