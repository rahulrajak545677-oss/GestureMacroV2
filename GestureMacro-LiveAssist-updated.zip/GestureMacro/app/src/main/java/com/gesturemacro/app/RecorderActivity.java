package com.gesturemacro.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * "New Gesture": a full-screen black canvas. Tap or swipe (with as many fingers as you like) and
 * everything is recorded with its timing, up to 60 seconds. Stop, Play to preview, Save to name it.
 */
public class RecorderActivity extends Activity {
    private static final long MAX_MS = 60000;
    private static final int IDLE = 0, RECORDING = 1, STOPPED = 2, PLAYING = 3;

    private final Handler h = new Handler(Looper.getMainLooper());
    private int state = IDLE;
    private long t0;
    private long previewStart;
    private float previewT;

    private RecCanvas canvas;
    private TextView btnSave, btnPlay, btnStop;
    private Timeline timeline;
    private LinearLayout topBar, bottomBar;

    private final ArrayList<Macro.Stroke> done = new ArrayList<>();
    private final SparseArray<Macro.Stroke> active = new SparseArray<>();

    // ------------------------------------------------------------------ setup

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        canvas = new RecCanvas();
        root.addView(canvas, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // top bar: Cancel | New Gesture | Save
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(0xF01C1C1E);
        topBar.setClickable(true);
        TextView cancel = Ui.tv(this, "Cancel", 17, Ui.BLUE);
        cancel.setPadding(Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12));
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        TextView title = Ui.tv(this, "New Gesture", 17, Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        btnSave = Ui.tv(this, "Save", 17, 0xFF5A5A5E);
        btnSave.setPadding(Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12));
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSave();
            }
        });
        topBar.addView(cancel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        topBar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        topBar.addView(btnSave, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(topBar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        // bottom bar: timeline, then Play | Stop
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        bottomBar.setBackgroundColor(0xF01C1C1E);
        bottomBar.setClickable(true);
        timeline = new Timeline();
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 14));
        tlp.setMargins(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), 0);
        bottomBar.addView(timeline, tlp);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        btnPlay = Ui.tv(this, "Play", 17, 0xFF5A5A5E);
        btnPlay.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 12));
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                play();
            }
        });
        btnStop = Ui.tv(this, "Stop", 17, 0xFF5A5A5E);
        btnStop.setGravity(Gravity.END);
        btnStop.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 12));
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (state == RECORDING) stopRecording();
            }
        });
        row.addView(btnPlay, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(btnStop, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bottomBar.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(bottomBar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        // keep the bars clear of camera cut-outs / system bars
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                topBar.setPadding(in.getSystemWindowInsetLeft() + Ui.dp(RecorderActivity.this, 8),
                        in.getSystemWindowInsetTop(),
                        in.getSystemWindowInsetRight() + Ui.dp(RecorderActivity.this, 8), 0);
                bottomBar.setPadding(in.getSystemWindowInsetLeft(), 0, in.getSystemWindowInsetRight(),
                        in.getSystemWindowInsetBottom());
                return in;
            }
        });

        setContentView(root);
        updateButtons();
        hideSystemUi();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ------------------------------------------------------------------ state

    private void updateButtons() {
        btnStop.setTextColor(state == RECORDING ? Ui.BLUE : 0xFF5A5A5E);
        btnPlay.setTextColor(state == STOPPED && !done.isEmpty() ? Ui.BLUE : 0xFF5A5A5E);
        boolean canSave = (state == STOPPED || state == RECORDING) && (!done.isEmpty() || active.size() > 0);
        btnSave.setTextColor(canSave ? Ui.BLUE : 0xFF5A5A5E);
    }

    private final Runnable recordTick = new Runnable() {
        @Override
        public void run() {
            if (state != RECORDING) return;
            long el = SystemClock.uptimeMillis() - t0;
            timeline.setFraction(Math.min(1f, el / (float) MAX_MS));
            if (el >= MAX_MS) {
                stopRecording();
                return;
            }
            h.postDelayed(this, 50);
        }
    };

    private void beginRecording(long eventTime) {
        state = RECORDING;
        t0 = eventTime;
        // lock the rotation so every point is recorded in the same screen orientation
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);
        updateButtons();
        h.post(recordTick);
    }

    private void stopRecording() {
        if (state != RECORDING) return;
        long t = SystemClock.uptimeMillis() - t0;
        for (int i = active.size() - 1; i >= 0; i--) {
            Macro.Stroke s = active.valueAt(i);
            finishStroke(s, t);
        }
        active.clear();
        state = STOPPED;
        updateButtons();
        canvas.invalidate();
    }

    private void play() {
        if (state != STOPPED || done.isEmpty()) return;
        state = PLAYING;
        previewStart = SystemClock.uptimeMillis();
        updateButtons();
        h.post(new Runnable() {
            @Override
            public void run() {
                if (state != PLAYING) return;
                previewT = SystemClock.uptimeMillis() - previewStart;
                canvas.invalidate();
                timeline.setFraction(Math.min(1f, previewT / (float) MAX_MS));
                if (previewT > duration() + 300) {
                    state = STOPPED;
                    updateButtons();
                    canvas.invalidate();
                } else {
                    h.postDelayed(this, 16);
                }
            }
        });
    }

    private long duration() {
        long d = 0;
        for (Macro.Stroke s : done) d = Math.max(d, s.endMs);
        return d;
    }

    // ------------------------------------------------------------------ strokes

    private void startStroke(int id, float x, float y, long t) {
        Macro.Stroke s = new Macro.Stroke();
        s.startMs = t;
        s.endMs = t;
        s.pts.add(new float[]{x, y, t});
        active.put(id, s);
    }

    private void addPoint(Macro.Stroke s, float x, float y, long t) {
        float[] last = s.pts.get(s.pts.size() - 1);
        if (t <= last[2]) return;
        float moved = Math.abs(x - last[0]) + Math.abs(y - last[1]);
        if (moved < Ui.dp(this, 2) && t - last[2] < 40) return;
        s.pts.add(new float[]{x, y, t});
        s.endMs = t;
    }

    private void finishStroke(Macro.Stroke s, long t) {
        float[] last = s.pts.get(s.pts.size() - 1);
        if (t > last[2]) {
            s.pts.add(new float[]{last[0], last[1], t});
        } else if (s.pts.size() == 1) {
            s.pts.add(new float[]{last[0], last[1], last[2] + 1});
        }
        s.endMs = Math.max(t, (long) last[2]);
        done.add(s);
    }

    // ------------------------------------------------------------------ saving

    private void onSave() {
        if (state == RECORDING) stopRecording();
        if (done.isEmpty() || state == PLAYING) return;

        final EditText et = new EditText(this);
        et.setHint("Gesture name");
        et.setSingleLine(true);
        AlertDialog.Builder b = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        b.setTitle("New Gesture");
        b.setView(et);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int which) {
                doSave(et.getText().toString());
            }
        });
        AlertDialog dlg = b.create();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        }
        dlg.show();
    }

    private void doSave(String name) {
        Macro m = new Macro();
        m.id = String.valueOf(System.currentTimeMillis());
        String clean = name == null ? "" : name.trim();
        m.name = clean.isEmpty() ? "Gesture " + (Store.loadMacros(this).size() + 1) : clean;

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        m.screenW = dm.widthPixels;
        m.screenH = dm.heightPixels;

        int[] loc = new int[2];
        canvas.getLocationOnScreen(loc);

        List<Macro.Stroke> sorted = new ArrayList<>(done);
        Collections.sort(sorted, new Comparator<Macro.Stroke>() {
            @Override
            public int compare(Macro.Stroke a, Macro.Stroke b) {
                return Long.compare(a.startMs, b.startMs);
            }
        });
        for (Macro.Stroke s : sorted) {
            Macro.Stroke c = new Macro.Stroke();
            c.startMs = s.startMs;
            c.endMs = s.endMs;
            for (float[] p : s.pts) c.pts.add(new float[]{p[0] + loc[0], p[1] + loc[1], p[2]});
            m.strokes.add(c);
            m.durationMs = Math.max(m.durationMs, c.endMs);
        }
        Store.addMacro(this, m);
        Toast.makeText(this, "Saved \"" + m.name + "\"", Toast.LENGTH_SHORT).show();
        finish();
    }

    // ------------------------------------------------------------------ views

    private class Timeline extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float frac;

        Timeline() {
            super(RecorderActivity.this);
        }

        void setFraction(float f) {
            frac = f;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float cy = getHeight() / 2f;
            float th = Ui.dp(RecorderActivity.this, 3);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF48484A);
            c.drawRoundRect(0, cy - th / 2f, w, cy + th / 2f, th, th, p);
            p.setColor(Ui.BLUE);
            c.drawRoundRect(0, cy - th / 2f, w * frac, cy + th / 2f, th, th, p);
            c.drawCircle(Math.max(th * 1.5f, w * frac), cy, th * 1.6f, p);
        }
    }

    private class RecCanvas extends View {
        private final Paint brush = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint hint = new Paint(Paint.ANTI_ALIAS_FLAG);

        RecCanvas() {
            super(RecorderActivity.this);
            brush.setStyle(Paint.Style.STROKE);
            brush.setStrokeCap(Paint.Cap.ROUND);
            brush.setStrokeJoin(Paint.Join.ROUND);
            brush.setStrokeWidth(Ui.dp(RecorderActivity.this, 34));
            hint.setColor(Ui.SUB);
            hint.setTextAlign(Paint.Align.CENTER);
            hint.setTextSize(Ui.dp(RecorderActivity.this, 15));
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (state == STOPPED || state == PLAYING) return true;
            int a = e.getActionMasked();
            if (state == IDLE) {
                if (a != MotionEvent.ACTION_DOWN) return true;
                beginRecording(e.getEventTime());
            }
            long t = e.getEventTime() - t0;
            switch (a) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN: {
                    int idx = e.getActionIndex();
                    startStroke(e.getPointerId(idx), e.getX(idx), e.getY(idx), t);
                    updateButtons();
                    break;
                }
                case MotionEvent.ACTION_MOVE: {
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        Macro.Stroke s = active.get(e.getPointerId(i));
                        if (s == null) continue;
                        for (int k = 0; k < e.getHistorySize(); k++) {
                            addPoint(s, e.getHistoricalX(i, k), e.getHistoricalY(i, k), e.getHistoricalEventTime(k) - t0);
                        }
                        addPoint(s, e.getX(i), e.getY(i), t);
                    }
                    break;
                }
                case MotionEvent.ACTION_POINTER_UP:
                case MotionEvent.ACTION_UP: {
                    int idx = e.getActionIndex();
                    int id = e.getPointerId(idx);
                    Macro.Stroke s = active.get(id);
                    if (s != null) {
                        addPoint(s, e.getX(idx), e.getY(idx), t);
                        finishStroke(s, t);
                        active.remove(id);
                    }
                    updateButtons();
                    break;
                }
                case MotionEvent.ACTION_CANCEL: {
                    for (int i = active.size() - 1; i >= 0; i--) finishStroke(active.valueAt(i), t);
                    active.clear();
                    updateButtons();
                    break;
                }
                default:
                    break;
            }
            invalidate();
            return true;
        }

        private void drawStroke(Canvas c, Macro.Stroke s, int color, float untilT) {
            if (s.startMs > untilT) return;
            Path p = new Path();
            boolean started = false;
            for (float[] q : s.pts) {
                if (q[2] > untilT) break;
                if (!started) {
                    p.moveTo(q[0], q[1]);
                    p.lineTo(q[0] + 0.1f, q[1]);
                    started = true;
                } else {
                    p.lineTo(q[0], q[1]);
                }
            }
            brush.setColor(color);
            c.drawPath(p, brush);
        }

        @Override
        protected void onDraw(Canvas c) {
            if (state == IDLE) {
                float cx = getWidth() / 2f;
                float cy = getHeight() * 0.62f;
                float lh = Ui.dp(RecorderActivity.this, 20);
                c.drawText("Tap or swipe to create a custom gesture.", cx, cy, hint);
                c.drawText("A sequence of gestures will be combined", cx, cy + lh * 2f, hint);
                c.drawText("into one multiple-touch gesture.", cx, cy + lh * 3f, hint);
            }
            boolean preview = state == PLAYING;
            for (Macro.Stroke s : done) {
                if (preview) drawStroke(c, s, 0xE61EA7D4, previewT);
                else drawStroke(c, s, 0xFFAEAEB2, Float.MAX_VALUE);
            }
            for (int i = 0; i < active.size(); i++) {
                drawStroke(c, active.valueAt(i), 0xE61EA7D4, Float.MAX_VALUE);
            }
        }
    }
}
