package com.gesturemacro.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * The heart of the app. It lives as an Android Accessibility Service, which is the only
 * official way on Android for an app to draw above other apps without extra permissions
 * and to perform taps / swipes in other apps (the same idea as iPhone's AssistiveTouch).
 */
public class GestureService extends AccessibilityService {
    public static volatile GestureService instance;

    private static final int MAX_STROKES = 10; // Android limit per dispatched gesture

    private WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private SharedPreferences.OnSharedPreferenceChangeListener prefListener;

    // floating button
    private AtButtonView button;
    private WindowManager.LayoutParams btnLp;
    private int btnSize;
    private float downRawX, downRawY;
    private int startX, startY;
    private boolean dragging, longFired;
    private long lastTapTime;
    private Runnable pendingSingle;

    // overlays
    private FrameLayout menuRoot;
    private PickerView picker;
    private TouchIndicatorView indicators;
    private ArmedView armedView;
    private Macro armed;
    private boolean merging;
    private float armSx, armSy;
    private final Runnable disarmRun = new Runnable() {
        @Override
        public void run() {
            disarm();
        }
    };
    private final List<Runnable> playRunnables = new ArrayList<>();

    // live assist (see the "live assist" section at the end of this file)
    private static final int TRIGGER_DP = 72;
    private TriggerView trigger;
    private WindowManager.LayoutParams triggerLp;
    private float triggerEditDownX, triggerEditDownY;
    private int triggerEditStartX, triggerEditStartY;
    private boolean triggerEditing;
    private Macro assistMacro;
    private AssistMath guide;
    private boolean liveActive, liveEnded, liveBusy;
    private boolean assistIndicatorsMerged;
    private GestureDescription.StrokeDescription liveStroke;
    private float liveStartX, liveStartY;   // where the real finger went down
    private float liveFx, liveFy;           // where the real finger is now
    private float liveOutX, liveOutY;       // where the injected (assisted) touch is now
    private float liveTx, liveTy;           // where the injected touch should go next
    private float liveSpeed;                // real finger speed, px per ms
    private int liveW, liveH;
    private long liveDownAt, liveLastMoveAt, liveEndAt;

    private static class MenuItem {
        final String label;
        final int icon;
        final Runnable action;

        MenuItem(String label, int icon, Runnable action) {
            this.label = label;
            this.icon = icon;
            this.action = action;
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        prefs = Store.prefs(this);
        prefListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override
            public void onSharedPreferenceChanged(SharedPreferences p, final String key) {
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        refreshButton();
                        // the trigger only ever moves because its position was changed in settings
                        if ("trigger_fx".equals(key) || "trigger_fy".equals(key)) placeTrigger();
                    }
                });
            }
        };
        prefs.registerOnSharedPreferenceChangeListener(prefListener);
        refreshButton();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    private void cleanup() {
        instance = null;
        stopPlayback();
        stopAssist();
        disarm();
        closeMenu();
        closePicker();
        removeButton();
        if (prefs != null && prefListener != null) {
            prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        h.post(new Runnable() {
            @Override
            public void run() {
                closeMenu();
                closePicker();
                disarm();
                stopAssist();
                placeButton();
            }
        });
    }

    // ------------------------------------------------------------------ helpers

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private DisplayMetrics realMetrics() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return dm;
    }

    private WindowManager.LayoutParams overlayParams(int w, int hh, int flags) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                w, hh, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return p;
    }

    private static final int FULL_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void feedback() {
        if (button == null) return;
        if (Store.b(this, "vibration", true)) {
            button.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        }
        if (Store.b(this, "sound_on_click", false)) {
            button.playSoundEffect(SoundEffectConstants.CLICK);
        }
    }

    // ------------------------------------------------------------------ floating button

    private float idleAlpha() {
        return Store.i(this, "idle_opacity", 37) / 100f;
    }

    private final Runnable idleFade = new Runnable() {
        @Override
        public void run() {
            if (button != null) button.animate().alpha(idleAlpha()).setDuration(250).start();
        }
    };

    private void refreshButton() {
        if (wm == null) return;
        if (!Store.b(this, "at_enabled", true)) {
            closeMenu();
            removeButton();
            return;
        }
        if (button == null) {
            addButton();
        } else {
            h.removeCallbacks(idleFade);
            h.postDelayed(idleFade, 600);
        }
    }

    private void addButton() {
        btnSize = dp(54);
        button = new AtButtonView(this);
        btnLp = overlayParams(btnSize, btnSize, FULL_FLAGS);
        placeButtonFromPrefs();
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                return handleButtonTouch(e);
            }
        });
        try {
            wm.addView(button, btnLp);
        } catch (Exception ex) {
            button = null;
            return;
        }
        button.setAlpha(1f);
        h.postDelayed(idleFade, 2500);
    }

    private void removeButton() {
        h.removeCallbacks(idleFade);
        if (button != null) {
            try {
                wm.removeView(button);
            } catch (Exception ignored) {
            }
            button = null;
        }
    }

    private void placeButtonFromPrefs() {
        DisplayMetrics dm = realMetrics();
        float fx = Store.f(this, "btn_fx", 1f);
        float fy = Store.f(this, "btn_fy", 0.45f);
        int margin = dp(4);
        btnLp.x = margin + Math.round(fx * Math.max(0, dm.widthPixels - btnSize - 2 * margin));
        btnLp.y = Math.round(fy * Math.max(0, dm.heightPixels - btnSize));
    }

    private void placeButton() {
        if (button == null) return;
        placeButtonFromPrefs();
        try {
            wm.updateViewLayout(button, btnLp);
        } catch (Exception ignored) {
        }
    }

    private boolean handleButtonTouch(MotionEvent e) {
        final int slop = dp(8);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = e.getRawX();
                downRawY = e.getRawY();
                startX = btnLp.x;
                startY = btnLp.y;
                dragging = false;
                longFired = false;
                h.removeCallbacks(idleFade);
                button.animate().cancel();
                button.setAlpha(1f);
                h.postDelayed(longPressRun, 550);
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getRawX() - downRawX;
                float dy = e.getRawY() - downRawY;
                if (!dragging && Math.hypot(dx, dy) > slop) {
                    dragging = true;
                    h.removeCallbacks(longPressRun);
                }
                if (dragging) {
                    DisplayMetrics dm = realMetrics();
                    btnLp.x = Math.max(0, Math.min(dm.widthPixels - btnSize, Math.round(startX + dx)));
                    btnLp.y = Math.max(0, Math.min(dm.heightPixels - btnSize, Math.round(startY + dy)));
                    try {
                        wm.updateViewLayout(button, btnLp);
                    } catch (Exception ignored) {
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
                h.removeCallbacks(longPressRun);
                if (dragging) {
                    snapToEdge();
                } else if (!longFired) {
                    onButtonTap();
                }
                h.postDelayed(idleFade, 3000);
                return true;
            case MotionEvent.ACTION_CANCEL:
                h.removeCallbacks(longPressRun);
                h.postDelayed(idleFade, 3000);
                return true;
            default:
                return true;
        }
    }

    private final Runnable longPressRun = new Runnable() {
        @Override
        public void run() {
            longFired = true;
            feedback();
            if (armed != null || assistMacro != null) {
                disarm();
                stopAssist();
                toast("Cancelled");
                return;
            }
            runAction(Store.s(GestureService.this, "long_press", "none"));
        }
    };

    private void snapToEdge() {
        DisplayMetrics dm = realMetrics();
        int margin = dp(4);
        boolean left = btnLp.x + btnSize / 2 < dm.widthPixels / 2;
        btnLp.x = left ? margin : dm.widthPixels - btnSize - margin;
        try {
            wm.updateViewLayout(button, btnLp);
        } catch (Exception ignored) {
        }
        float freeW = Math.max(1, dm.widthPixels - btnSize - 2 * margin);
        float freeH = Math.max(1, dm.heightPixels - btnSize);
        Store.setF(this, "btn_fx", Math.max(0f, Math.min(1f, (btnLp.x - margin) / freeW)));
        Store.setF(this, "btn_fy", Math.max(0f, Math.min(1f, btnLp.y / freeH)));
    }

    private void onButtonTap() {
        feedback();
        long now = SystemClock.uptimeMillis();
        if (armed != null) {
            // gesture is armed (red circles are showing): double-tap plays it, a single tap cancels
            if (pendingSingle != null && now - lastTapTime < 320) {
                h.removeCallbacks(pendingSingle);
                pendingSingle = null;
                fireArmed();
                return;
            }
            lastTapTime = now;
            pendingSingle = new Runnable() {
                @Override
                public void run() {
                    pendingSingle = null;
                    if (armed != null) {
                        disarm();
                        toast("Cancelled");
                    }
                }
            };
            h.postDelayed(pendingSingle, 330);
            return;
        }
        if (pendingSingle != null && now - lastTapTime < 320) {
            h.removeCallbacks(pendingSingle);
            pendingSingle = null;
            if (assistMacro != null) {
                // In Live Assist, double-tap merges the two live touch indicators into one.
                // It does not move the fixed trigger and does not play the saved macro.
                setAssistIndicatorsMerged(true);
            } else {
                runAction(Store.s(this, "double_tap", "menu"));
            }
            return;
        }
        lastTapTime = now;
        final String single = Store.s(this, "single_tap", "none");
        if ("none".equals(Store.s(this, "double_tap", "menu"))) {
            runAction(single);
            return;
        }
        pendingSingle = new Runnable() {
            @Override
            public void run() {
                pendingSingle = null;
                runAction(single);
            }
        };
        h.postDelayed(pendingSingle, 300);
    }

    // ------------------------------------------------------------------ actions

    private void runAction(String a) {
        if (a == null || a.equals("none")) return;
        if (a.equals("menu")) {
            if (menuRoot != null) closeMenu(); else openMenu();
            return;
        }
        if (a.startsWith("macro:")) {
            Macro m = Store.findMacro(this, a.substring(6));
            if (m != null) playOrArm(m, true);
            return;
        }
        closeMenu();
        switch (a) {
            case "home": performGlobalAction(GLOBAL_ACTION_HOME); break;
            case "back": performGlobalAction(GLOBAL_ACTION_BACK); break;
            case "recents": performGlobalAction(GLOBAL_ACTION_RECENTS); break;
            case "notifications": performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); break;
            case "quick_settings": performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS); break;
            case "power": performGlobalAction(GLOBAL_ACTION_POWER_DIALOG); break;
            case "lock":
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
                else toast("Lock Screen needs Android 9 or newer");
                break;
            case "screenshot":
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
                else toast("Screenshot needs Android 9 or newer");
                break;
            case "vol_up": volume(AudioManager.ADJUST_RAISE); break;
            case "vol_down": volume(AudioManager.ADJUST_LOWER); break;
            case "mute": volume(AudioManager.ADJUST_TOGGLE_MUTE); break;
            default: break;
        }
    }

    private void volume(int dir) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (am != null) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
    }

    // ------------------------------------------------------------------ menu

    private void openMenu() {
        closeMenu();
        menuRoot = new FrameLayout(this);
        menuRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeMenu();
            }
        });
        try {
            wm.addView(menuRoot, overlayParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, FULL_FLAGS));
        } catch (Exception ex) {
            menuRoot = null;
            return;
        }
        showMenuPage("top");
    }

    private void closeMenu() {
        if (menuRoot != null) {
            try {
                wm.removeView(menuRoot);
            } catch (Exception ignored) {
            }
            menuRoot = null;
        }
    }

    private MenuItem item(String label, int icon, Runnable r) {
        return new MenuItem(label, icon, r);
    }

    private Runnable page(final String name) {
        return new Runnable() {
            @Override
            public void run() {
                showMenuPage(name);
            }
        };
    }

    private Runnable action(final String id) {
        return new Runnable() {
            @Override
            public void run() {
                runAction(id);
            }
        };
    }

    private Runnable picker(final String mode) {
        return new Runnable() {
            @Override
            public void run() {
                startPicker(mode);
            }
        };
    }

    private List<MenuItem> itemsFor(String pageName) {
        List<MenuItem> l = new ArrayList<>();
        if (pageName.equals("top")) {
            for (String k : Store.menuItems(this)) {
                switch (k) {
                    case "custom": l.add(item("Custom", IconView.STAR, page("custom"))); break;
                    case "notifications": l.add(item("Notification Center", IconView.BELL, action("notifications"))); break;
                    case "device": l.add(item("Device", IconView.DEVICE, page("device"))); break;
                    case "gestures": l.add(item("Gestures", IconView.GESTURES, page("gestures"))); break;
                    case "home": l.add(item("Home", IconView.HOME, action("home"))); break;
                    case "control": l.add(item("Control Center", IconView.TOGGLES, action("quick_settings"))); break;
                    default: break;
                }
            }
        } else if (pageName.equals("custom")) {
            l.add(item("Pinch and Rotate", IconView.PINCH, picker(PickerView.PINCH)));
            l.add(item("Long Press", IconView.LONGPRESS, picker(PickerView.LONGPRESS)));
            l.add(item("Double Tap", IconView.DOUBLETAP, picker(PickerView.DOUBLETAP)));
            l.add(item("Hold and Drag", IconView.HOLDDRAG, picker(PickerView.HOLDDRAG)));
            for (final Macro m : Store.loadMacros(this)) {
                l.add(item(m.name, IconView.STAR, new Runnable() {
                    @Override
                    public void run() {
                        playOrArm(m, false);
                    }
                }));
            }
            Runnable openApp = new Runnable() {
                @Override
                public void run() {
                    closeMenu();
                    Intent i = new Intent(GestureService.this, MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                }
            };
            // The centre cell of a sub page is the Back arrow, so one page holds 8 icons.
            // Empty slots show the dashed "+" (it opens the app so you can record a new gesture).
            if (l.size() < 8) {
                while (l.size() < 8) l.add(item("", IconView.PLUS, openApp));
            } else {
                l.add(item("", IconView.PLUS, openApp));
            }
        } else if (pageName.equals("device")) {
            l.add(item("Lock Screen", IconView.LOCK, action("lock")));
            l.add(item("Screenshot", IconView.SCREENSHOT, action("screenshot")));
            l.add(item("Recent Apps", IconView.RECENTS, action("recents")));
            l.add(item("Volume Up", IconView.VOLUP, action("vol_up")));
            l.add(item("Volume Down", IconView.VOLDOWN, action("vol_down")));
            l.add(item("Mute", IconView.MUTE, action("mute")));
            l.add(item("Power Menu", IconView.POWER, action("power")));
        } else if (pageName.equals("gestures")) {
            l.add(item("Swipe Up", IconView.UP, swipe(0)));
            l.add(item("Swipe Down", IconView.DOWN, swipe(1)));
            l.add(item("Swipe Left", IconView.LEFT, swipe(2)));
            l.add(item("Swipe Right", IconView.RIGHT, swipe(3)));
            l.add(item("Zoom In", IconView.ZOOMIN, zoom(true)));
            l.add(item("Zoom Out", IconView.ZOOMOUT, zoom(false)));
            l.add(item("Back", IconView.BACK, action("back")));
        }
        return l;
    }

    private void showMenuPage(String pageName) {
        if (menuRoot == null) return;
        menuRoot.removeAllViews();
        List<MenuItem> items = itemsFor(pageName);
        List<MenuItem> cells = new ArrayList<>();
        if (pageName.equals("top")) {
            cells.addAll(items);
        } else {
            MenuItem back = item("", IconView.BACK, page("top"));
            for (MenuItem it : items) {
                if (cells.size() == 4) cells.add(back);
                cells.add(it);
            }
            while (cells.size() < 4) cells.add(null);
            if (cells.size() == 4) cells.add(back);
        }
        while (cells.size() % 3 != 0) cells.add(null);

        final int cellW = dp(96);
        final int cellH = dp(88);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < cells.size() / 3; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 3; c++) {
                row.addView(cellView(cells.get(r * 3 + c)), new LinearLayout.LayoutParams(cellW, cellH));
            }
            grid.addView(row);
        }

        DisplayMetrics dm = realMetrics();
        int padding = dp(10);
        int gridH = (cells.size() / 3) * cellH;
        int maxH = Math.round(dm.heightPixels * 0.80f) - 2 * padding;

        FrameLayout panel = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF01F1D1B);
        bg.setCornerRadius(dp(26));
        panel.setBackground(bg);
        panel.setPadding(padding, padding, padding, padding);
        panel.setClickable(true); // taps on the panel itself must not close the menu
        if (gridH > maxH) {
            ScrollView sv = new ScrollView(this);
            sv.addView(grid);
            panel.addView(sv, new FrameLayout.LayoutParams(cellW * 3, maxH));
        } else {
            panel.addView(grid, new FrameLayout.LayoutParams(cellW * 3, gridH));
        }
        menuRoot.addView(panel, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        panel.setAlpha(0f);
        panel.setScaleX(0.8f);
        panel.setScaleY(0.8f);
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(150).start();
    }

    private View cellView(final MenuItem it) {
        if (it == null) return new View(this);
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setPadding(0, dp(8), 0, 0);
        cell.addView(new IconView(this, it.icon), new LinearLayout.LayoutParams(dp(46), dp(46)));
        TextView label = new TextView(this);
        label.setText(it.label);
        label.setTextColor(Color.WHITE);
        label.setTextSize(12);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        label.setPadding(dp(2), dp(4), dp(2), 0);
        cell.addView(label, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                feedback();
                it.action.run();
            }
        });
        return cell;
    }

    // ------------------------------------------------------------------ playing recorded gestures

    private void stopPlayback() {
        for (Runnable r : playRunnables) h.removeCallbacks(r);
        playRunnables.clear();
        removeIndicators();
    }

    private void removeIndicators() {
        if (indicators != null) {
            try {
                wm.removeView(indicators);
            } catch (Exception ignored) {
            }
            indicators = null;
        }
    }

    private void playOrArm(Macro m, boolean autoFire) {
        // Live Assist never plays the gesture: it only shapes the drag of your own finger.
        if (Store.b(this, "live_assist", true)) {
            startAssist(m);
            return;
        }
        if (Store.b(this, "arm_mode", true)) armMacro(m, autoFire);
        else playMacro(m);
    }

    private boolean orientationOk(Macro m) {
        DisplayMetrics dm = realMetrics();
        boolean recLandscape = m.screenW > m.screenH;
        boolean curLandscape = dm.widthPixels > dm.heightPixels;
        if (recLandscape != curLandscape) {
            toast("Rotate your phone to " + (recLandscape ? "landscape" : "portrait") + " to play \"" + m.name + "\"");
            return false;
        }
        return true;
    }

    private void removeArmedView() {
        if (armedView != null) {
            try {
                wm.removeView(armedView);
            } catch (Exception ignored) {
            }
            armedView = null;
        }
    }

    private void disarm() {
        h.removeCallbacks(disarmRun);
        merging = false;
        armed = null;
        removeArmedView();
    }

    /**
     * Step 1: red circles appear where every touch of the gesture starts.
     * Step 2: double-tap the floating button -> the circles merge into one and the gesture plays.
     * autoFire = true skips the waiting (used when the gesture is bound to Single-Tap/Double-Tap/Long Press).
     */
    private void armMacro(final Macro m, boolean autoFire) {
        closeMenu();
        stopPlayback();
        disarm();
        if (m.strokes.isEmpty() || !orientationOk(m)) return;
        DisplayMetrics dm = realMetrics();
        armSx = dm.widthPixels / (float) m.screenW;
        armSy = dm.heightPixels / (float) m.screenH;

        List<Macro.Stroke> sorted = new ArrayList<>(m.strokes);
        Collections.sort(sorted, new Comparator<Macro.Stroke>() {
            @Override
            public int compare(Macro.Stroke a, Macro.Stroke b) {
                return Long.compare(a.startMs, b.startMs);
            }
        });
        ArrayList<Float> spots = new ArrayList<>();
        float minGap = dp(24);
        for (Macro.Stroke s : sorted) {
            float x = s.pts.get(0)[0] * armSx;
            float y = s.pts.get(0)[1] * armSy;
            boolean dup = false;
            for (int i = 0; i + 1 < spots.size(); i += 2) {
                if (Math.hypot(spots.get(i) - x, spots.get(i + 1) - y) < minGap) {
                    dup = true;
                    break;
                }
            }
            if (!dup) {
                spots.add(x);
                spots.add(y);
            }
        }
        float[] xy = new float[spots.size()];
        for (int i = 0; i < xy.length; i++) xy[i] = spots.get(i);

        armed = m;
        armedView = new ArmedView(this, xy);
        if (!Store.b(this, "show_touches", true)) armedView.setAlpha(0f);
        try {
            wm.addView(armedView, overlayParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    FULL_FLAGS | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE));
        } catch (Exception ex) {
            armedView = null;
            armed = null;
            playMacro(m);
            return;
        }
        if (autoFire) {
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (armed == m) fireArmed();
                }
            }, 350);
        } else {
            toast("Double-tap the button to play \"" + m.name + "\". Tap once to cancel.");
            h.postDelayed(disarmRun, 60000);
        }
    }

    private void fireArmed() {
        final Macro m = armed;
        if (m == null || armedView == null || merging) return;
        merging = true;
        h.removeCallbacks(disarmRun);
        armedView.merge(new Runnable() {
            @Override
            public void run() {
                merging = false;
                removeArmedView();
                armed = null;
                startPlayback(m, armSx, armSy);
            }
        });
    }

    private void playMacro(final Macro m) {
        closeMenu();
        stopPlayback();
        DisplayMetrics dm = realMetrics();
        boolean recLandscape = m.screenW > m.screenH;
        boolean curLandscape = dm.widthPixels > dm.heightPixels;
        if (recLandscape != curLandscape) {
            toast("Rotate your phone to " + (recLandscape ? "landscape" : "portrait") + " to play \"" + m.name + "\"");
            return;
        }
        final float sx = dm.widthPixels / (float) m.screenW;
        final float sy = dm.heightPixels / (float) m.screenH;
        Runnable start = new Runnable() {
            @Override
            public void run() {
                playRunnables.remove(this);
                startPlayback(m, sx, sy);
            }
        };
        playRunnables.add(start);
        h.postDelayed(start, 250); // let the menu disappear first so the touch reaches the app below
    }

    private void startPlayback(final Macro m, final float sx, final float sy) {
        if (m.strokes.isEmpty()) return;
        List<Macro.Stroke> sorted = new ArrayList<>(m.strokes);
        Collections.sort(sorted, new Comparator<Macro.Stroke>() {
            @Override
            public int compare(Macro.Stroke a, Macro.Stroke b) {
                return Long.compare(a.startMs, b.startMs);
            }
        });

        // Android lets one dispatched gesture hold at most 10 strokes, and a new gesture cancels the
        // one still running. So long macros are cut into batches that start after the previous ended.
        List<List<Macro.Stroke>> batches = new ArrayList<>();
        List<Macro.Stroke> cur = null;
        long curEnd = 0;
        int dropped = 0;
        for (Macro.Stroke s : sorted) {
            if (cur == null) {
                cur = new ArrayList<>();
                cur.add(s);
                curEnd = s.endMs;
                batches.add(cur);
            } else if (cur.size() < MAX_STROKES) {
                cur.add(s);
                curEnd = Math.max(curEnd, s.endMs);
            } else if (s.startMs >= curEnd) {
                cur = new ArrayList<>();
                cur.add(s);
                curEnd = s.endMs;
                batches.add(cur);
            } else {
                dropped++;
            }
        }
        if (dropped > 0) toast("Skipped " + dropped + " touches (more than 10 fingers at once)");

        for (final List<Macro.Stroke> batch : batches) {
            final long t0 = batch.get(0).startMs;
            Runnable r = new Runnable() {
                @Override
                public void run() {
                    playRunnables.remove(this);
                    dispatchBatch(m, batch, t0, sx, sy);
                }
            };
            playRunnables.add(r);
            h.postDelayed(r, t0);
        }

        if (Store.b(this, "show_touches", true)) {
            removeIndicators();
            indicators = new TouchIndicatorView(this);
            try {
                wm.addView(indicators, overlayParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        FULL_FLAGS | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE));
                final long base = SystemClock.uptimeMillis();
                final long total = m.durationMs + 700;
                Runnable tick = new Runnable() {
                    @Override
                    public void run() {
                        long t = SystemClock.uptimeMillis() - base;
                        if (indicators == null) return;
                        indicators.update(positionsAt(m, sx, sy, t), t);
                        if (t < total) {
                            h.postDelayed(this, 16);
                        } else {
                            removeIndicators();
                        }
                    }
                };
                h.post(tick);
            } catch (Exception ex) {
                indicators = null;
            }
        }
    }

    private float[] positionsAt(Macro m, float sx, float sy, long t) {
        ArrayList<Float> out = new ArrayList<>();
        for (Macro.Stroke s : m.strokes) {
            if (t < s.startMs || t > s.endMs + 40) continue;
            float[] p = s.pts.get(s.pts.size() - 1);
            float x = p[0];
            float y = p[1];
            for (int i = 0; i + 1 < s.pts.size(); i++) {
                float[] a = s.pts.get(i);
                float[] b = s.pts.get(i + 1);
                if (t >= a[2] && t <= b[2]) {
                    float k = b[2] > a[2] ? (t - a[2]) / (b[2] - a[2]) : 0f;
                    x = a[0] + (b[0] - a[0]) * k;
                    y = a[1] + (b[1] - a[1]) * k;
                    break;
                }
            }
            out.add(x * sx);
            out.add(y * sy);
        }
        float[] arr = new float[out.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = out.get(i);
        return arr;
    }

    private float clamp(float v, float max) {
        return Math.max(0f, Math.min(max - 1f, v));
    }

    private void dispatchBatch(Macro m, List<Macro.Stroke> batch, long t0, float sx, float sy) {
        DisplayMetrics dm = realMetrics();
        try {
            GestureDescription.Builder b = new GestureDescription.Builder();
            for (Macro.Stroke s : batch) {
                Path p = new Path();
                float[] f = s.pts.get(0);
                p.moveTo(clamp(f[0] * sx, dm.widthPixels), clamp(f[1] * sy, dm.heightPixels));
                float lx = f[0];
                float ly = f[1];
                for (int i = 1; i < s.pts.size(); i++) {
                    float[] q = s.pts.get(i);
                    boolean last = i == s.pts.size() - 1;
                    if (Math.abs(q[0] - lx) + Math.abs(q[1] - ly) < 1.5f && !last) continue;
                    if (Math.abs(q[0] - lx) + Math.abs(q[1] - ly) < 0.5f) continue;
                    p.lineTo(clamp(q[0] * sx, dm.widthPixels), clamp(q[1] * sy, dm.heightPixels));
                    lx = q[0];
                    ly = q[1];
                }
                long dur = Math.max(10, s.endMs - s.startMs);
                b.addStroke(new GestureDescription.StrokeDescription(p, s.startMs - t0, dur));
            }
            if (!dispatchGesture(b.build(), null, null)) toast("Couldn't play \"" + m.name + "\"");
        } catch (Exception ex) {
            toast("Couldn't play \"" + m.name + "\"");
        }
    }

    // ------------------------------------------------------------------ built-in gestures (Custom / Gestures pages)

    private void send(GestureDescription.StrokeDescription... strokes) {
        try {
            GestureDescription.Builder b = new GestureDescription.Builder();
            for (GestureDescription.StrokeDescription s : strokes) b.addStroke(s);
            dispatchGesture(b.build(), null, null);
        } catch (Exception ex) {
            toast("Couldn't perform that gesture");
        }
    }

    private Path line(float x1, float y1, float x2, float y2) {
        Path p = new Path();
        p.moveTo(x1, y1);
        if (x1 != x2 || y1 != y2) p.lineTo(x2, y2);
        return p;
    }

    private Runnable swipe(final int dir) {
        return new Runnable() {
            @Override
            public void run() {
                closeMenu();
                DisplayMetrics dm = realMetrics();
                final float w = dm.widthPixels;
                final float hgt = dm.heightPixels;
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        float cx = w / 2f, cy = hgt / 2f;
                        float dx = 0, dy = 0;
                        if (dir == 0) dy = -hgt * 0.30f;
                        if (dir == 1) dy = hgt * 0.30f;
                        if (dir == 2) dx = -w * 0.30f;
                        if (dir == 3) dx = w * 0.30f;
                        send(new GestureDescription.StrokeDescription(line(cx - dx / 2f, cy - dy / 2f, cx + dx / 2f, cy + dy / 2f), 0, 350));
                    }
                }, 250);
            }
        };
    }

    private Runnable zoom(final boolean in) {
        return new Runnable() {
            @Override
            public void run() {
                closeMenu();
                DisplayMetrics dm = realMetrics();
                final float cx = dm.widthPixels / 2f;
                final float cy = dm.heightPixels / 2f;
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        float near = dp(50);
                        float far = dp(150);
                        float from = in ? near : far;
                        float to = in ? far : near;
                        send(new GestureDescription.StrokeDescription(line(cx - from, cy, cx - to, cy), 0, 450),
                                new GestureDescription.StrokeDescription(line(cx + from, cy, cx + to, cy), 0, 450));
                    }
                }, 250);
            }
        };
    }

    private void startPicker(final String mode) {
        closeMenu();
        closePicker();
        picker = new PickerView(this, mode, new PickerView.Callback() {
            @Override
            public void onDone(final float[] data) {
                closePicker();
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        performPicked(mode, data);
                    }
                }, 200);
            }

            @Override
            public void onCancel() {
                closePicker();
            }
        });
        try {
            wm.addView(picker, overlayParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, FULL_FLAGS));
        } catch (Exception ex) {
            picker = null;
        }
    }

    private void closePicker() {
        if (picker != null) {
            try {
                wm.removeView(picker);
            } catch (Exception ignored) {
            }
            picker = null;
        }
    }

    private void performPicked(String mode, float[] d) {
        if (mode.equals(PickerView.LONGPRESS)) {
            Path p = new Path();
            p.moveTo(d[0], d[1]);
            send(new GestureDescription.StrokeDescription(p, 0, 900));
        } else if (mode.equals(PickerView.DOUBLETAP)) {
            Path p1 = new Path();
            p1.moveTo(d[0], d[1]);
            Path p2 = new Path();
            p2.moveTo(d[0], d[1]);
            send(new GestureDescription.StrokeDescription(p1, 0, 40),
                    new GestureDescription.StrokeDescription(p2, 140, 40));
        } else if (mode.equals(PickerView.PINCH)) {
            send(new GestureDescription.StrokeDescription(line(d[0], d[1], d[4], d[5]), 0, 500),
                    new GestureDescription.StrokeDescription(line(d[2], d[3], d[6], d[7]), 0, 500));
        } else if (mode.equals(PickerView.HOLDDRAG)) {
            holdAndDrag(d);
        }
    }

    /** Press and hold at the start point for half a second, then drag along the path you drew. */
    private void holdAndDrag(float[] d) {
        int n = d.length / 3;
        final float x0 = d[0];
        final float y0 = d[1];
        final Path drag = new Path();
        drag.moveTo(x0 + 0.5f, y0);
        for (int i = 1; i < n; i++) drag.lineTo(d[i * 3], d[i * 3 + 1]);
        final long dragMs = Math.max(200, (long) d[(n - 1) * 3 + 2]);
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                Path hold = new Path();
                hold.moveTo(x0, y0);
                hold.lineTo(x0 + 0.5f, y0);
                final GestureDescription.StrokeDescription first =
                        new GestureDescription.StrokeDescription(hold, 0, 500, true);
                GestureDescription.Builder b = new GestureDescription.Builder();
                b.addStroke(first);
                dispatchGesture(b.build(), new GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription gestureDescription) {
                        GestureDescription.StrokeDescription second = first.continueStroke(drag, 0, dragMs, false);
                        GestureDescription.Builder b2 = new GestureDescription.Builder();
                        b2.addStroke(second);
                        dispatchGesture(b2.build(), null, null);
                    }
                }, null);
            } catch (Exception ex) {
                toast("Couldn't perform that gesture");
            }
        } else {
            Path p = new Path();
            p.moveTo(x0, y0);
            for (int i = 1; i < n; i++) p.lineTo(d[i * 3], d[i * 3 + 1]);
            send(new GestureDescription.StrokeDescription(p, 0, dragMs + 500));
        }
    }

    // ------------------------------------------------------------------ live assist
    //
    // The saved gesture is NEVER played here. It is only a guide for the drag of your own finger.
    //  1. One fixed red trigger window is on screen. It is the only window that takes touches, so
    //     only a finger that goes down ON the trigger is tracked. Everything else reaches the game.
    //  2. While that finger is down, its direction, distance, speed and duration are read.
    //  3. The touch the game sees is injected with dispatchGesture, in short segments that are
    //     chained with StrokeDescription.continueStroke. Where each segment ends is decided by
    //     AssistMath from how far the real finger has moved.
    //  4. Finger up (or cancel) lifts the injected touch. No finger, no injection. There is no timer
    //     and no playback code on this path.
    // The trigger window's x/y are only written by placeTrigger(), never by touches.

    private void startAssist(Macro m) {
        closeMenu();
        stopPlayback();
        disarm();
        stopAssist();
        if (Build.VERSION.SDK_INT < 26) {
            toast("Live Assist needs Android 8 or newer");
            return;
        }
        if (m.strokes.isEmpty() || !orientationOk(m)) return;
        DisplayMetrics dm = realMetrics();
        float sx = dm.widthPixels / (float) m.screenW;
        float sy = dm.heightPixels / (float) m.screenH;

        // the longest touch of the gesture is the guide
        Macro.Stroke best = m.strokes.get(0);
        float bestLen = -1f;
        for (Macro.Stroke s : m.strokes) {
            float len = 0f;
            for (int i = 1; i < s.pts.size(); i++) {
                len += (float) Math.hypot(s.pts.get(i)[0] - s.pts.get(i - 1)[0], s.pts.get(i)[1] - s.pts.get(i - 1)[1]);
            }
            if (len > bestLen) {
                bestLen = len;
                best = s;
            }
        }
        float[] xy = new float[best.pts.size() * 2];
        for (int i = 0; i < best.pts.size(); i++) {
            xy[i * 2] = best.pts.get(i)[0] * sx;
            xy[i * 2 + 1] = best.pts.get(i)[1] * sy;
        }
        guide = AssistMath.fromPoints(xy, dp(8));

        // First time only: put the trigger where the gesture starts. After that it stays where it
        // is until you change it in settings (Live Assist > Red Trigger Position).
        if (!prefs.contains("trigger_fx")) {
            Store.setF(this, "trigger_fx", Math.max(0f, Math.min(1f, xy[0] / dm.widthPixels)));
            Store.setF(this, "trigger_fy", Math.max(0f, Math.min(1f, xy[1] / dm.heightPixels)));
        }
        assistMacro = m;
        assistIndicatorsMerged = false;
        addTrigger();
        if (assistMacro == null) return;
        toast(guide.usable()
                ? "Press the red circle and drag. Long-press the floating button to stop."
                : "This gesture has no direction, so your finger is passed through unchanged.");
    }

    /** Double-tap on the AssistiveTouch icon merges the Live Assist indicators visually. */
    private void setAssistIndicatorsMerged(boolean merged) {
        assistIndicatorsMerged = merged;
        if (indicators != null) indicators.setMerged(merged);
        toast(merged ? "Touch indicators merged" : "Touch indicators separated");
    }

    /** Ends Live Assist: removes the trigger and lifts a held touch (if a finger is down right now). */
    private void stopAssist() {
        assistMacro = null;
        assistIndicatorsMerged = false;
        guide = null;
        removeTrigger();
        if (liveActive) {
            liveEnded = true;
            pumpLive();
        }
    }

    private void addTrigger() {
        removeTrigger();
        int size = dp(TRIGGER_DP);
        trigger = new TriggerView(this);
        triggerLp = overlayParams(size, size, FULL_FLAGS);
        placeTrigger();
        trigger.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                return handleTriggerTouch(e);
            }
        });
        try {
            wm.addView(trigger, triggerLp);
        } catch (Exception ex) {
            trigger = null;
            triggerLp = null;
            assistMacro = null;
            toast("Couldn't show the red trigger");
        }
    }

    private void removeTrigger() {
        if (trigger != null) {
            try {
                wm.removeView(trigger);
            } catch (Exception ignored) {
            }
            trigger = null;
            triggerLp = null;
        }
    }

    /** The ONLY place the trigger's position is written: when it is created and when settings change it. */
    private void placeTrigger() {
        if (trigger == null || triggerLp == null || liveActive) return;
        DisplayMetrics dm = realMetrics();
        int size = triggerLp.width;
        float fx = Store.f(this, "trigger_fx", 0.5f);
        float fy = Store.f(this, "trigger_fy", 0.5f);
        triggerLp.x = Math.max(0, Math.min(dm.widthPixels - size, Math.round(fx * dm.widthPixels) - size / 2));
        triggerLp.y = Math.max(0, Math.min(dm.heightPixels - size, Math.round(fy * dm.heightPixels) - size / 2));
        if (trigger.isAttachedToWindow()) {
            try {
                wm.updateViewLayout(trigger, triggerLp);
            } catch (Exception ignored) {
            }
        }
    }

    private void setTriggerTouchable(boolean touchable) {
        if (trigger == null || triggerLp == null) return;
        if (touchable) {
            triggerLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        } else {
            triggerLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        try {
            wm.updateViewLayout(trigger, triggerLp);   // flags only: x/y are not touched
        } catch (Exception ignored) {
        }
    }

    private boolean handleTriggerTouch(MotionEvent e) {
        // Explicit setup mode: dragging the red trigger repositions it. Outside setup mode,
        // the trigger is locked and a press-drag starts Live Assist as before.
        if (Store.b(this, "trigger_edit_mode", false)) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (liveActive || triggerLp == null) return true;
                    triggerEditing = true;
                    triggerEditDownX = e.getRawX();
                    triggerEditDownY = e.getRawY();
                    triggerEditStartX = triggerLp.x;
                    triggerEditStartY = triggerLp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (triggerEditing && triggerLp != null) {
                        DisplayMetrics dm = realMetrics();
                        triggerLp.x = Math.max(0, Math.min(dm.widthPixels - triggerLp.width,
                                Math.round(triggerEditStartX + e.getRawX() - triggerEditDownX)));
                        triggerLp.y = Math.max(0, Math.min(dm.heightPixels - triggerLp.height,
                                Math.round(triggerEditStartY + e.getRawY() - triggerEditDownY)));
                        try { wm.updateViewLayout(trigger, triggerLp); } catch (Exception ignored) {}
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (triggerEditing && triggerLp != null) {
                        triggerEditing = false;
                        DisplayMetrics dm = realMetrics();
                        Store.setF(this, "trigger_fx", (triggerLp.x + triggerLp.width / 2f) / Math.max(1, dm.widthPixels));
                        Store.setF(this, "trigger_fy", (triggerLp.y + triggerLp.height / 2f) / Math.max(1, dm.heightPixels));
                    }
                    return true;
                default:
                    return true;
            }
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!liveActive) beginLive(e.getRawX(), e.getRawY());
                return true;
            case MotionEvent.ACTION_MOVE:
                if (liveActive && !liveEnded) moveLive(e.getRawX(), e.getRawY());
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (liveActive && !liveEnded) {
                    liveEnded = true;
                    pumpLive();
                }
                return true;
            default:
                return true;
        }
    }

    private void beginLive(float rawX, float rawY) {
        DisplayMetrics dm = realMetrics();
        liveW = dm.widthPixels;
        liveH = dm.heightPixels;
        liveActive = true;
        liveEnded = false;
        liveBusy = false;
        liveStroke = null;
        liveStartX = liveFx = liveOutX = liveTx = rawX;
        liveStartY = liveFy = liveOutY = liveTy = rawY;
        liveSpeed = 0f;
        liveDownAt = liveLastMoveAt = SystemClock.uptimeMillis();
        if (trigger != null) trigger.setActive(true);
        // From now on the trigger lets touches through, so the injected touch reaches the game
        // below instead of landing on the trigger itself. Its position is not changed.
        setTriggerTouchable(false);
        startLiveIndicators();
        pumpLive();   // sends the first (held) touch after a short delay, see pumpLive
    }

    private void moveLive(float rawX, float rawY) {
        long now = SystemClock.uptimeMillis();
        float dt = Math.max(1L, now - liveLastMoveAt);
        liveSpeed = AssistMath.smooth(liveSpeed, (float) Math.hypot(rawX - liveFx, rawY - liveFy) / dt);
        liveLastMoveAt = now;
        liveFx = rawX;
        liveFy = rawY;
        float strength = Store.i(this, "assist_strength", 100) / 100f;
        float[] off = guide != null
                ? guide.offset(rawX - liveStartX, rawY - liveStartY, strength)
                : new float[]{rawX - liveStartX, rawY - liveStartY};
        liveTx = Math.max(0f, Math.min(liveW - 1f, liveStartX + off[0]));
        liveTy = Math.max(0f, Math.min(liveH - 1f, liveStartY + off[1]));
        pumpLive();
    }

    private final Runnable livePumpRun = new Runnable() {
        @Override
        public void run() {
            pumpLive();
        }
    };

    /** Sends the next segment of the held touch. One segment at a time: a new gesture would cancel the running one. */
    private void pumpLive() {
        if (!liveActive || liveBusy) return;
        final boolean finishing = liveEnded;
        final boolean first = liveStroke == null;
        if (first) {
            // give the "trigger is not touchable" change a moment to reach the system first
            long since = SystemClock.uptimeMillis() - liveDownAt;
            if (since < 50) {
                h.removeCallbacks(livePumpRun);
                h.postDelayed(livePumpRun, 50 - since);
                return;
            }
        }
        float segLen = (float) Math.hypot(liveTx - liveOutX, liveTy - liveOutY);
        boolean moved = segLen >= 0.5f;
        if (!first && !moved && !finishing) return;   // finger is still: nothing to send

        Path p = new Path();
        p.moveTo(liveOutX, liveOutY);
        float endX = liveOutX;
        float endY = liveOutY;
        long dur;
        if (first && !finishing) {
            endX = liveOutX + 0.5f;                   // a held touch needs a tiny line (as in Hold and Drag)
            p.lineTo(endX, endY);
            dur = 30;
        } else if (moved) {
            endX = liveTx;
            endY = liveTy;
            p.lineTo(endX, endY);
            dur = AssistMath.segmentMs(segLen, liveSpeed);
        } else {
            dur = first ? 40 : 12;                    // quick tap, or just lifting the held touch
        }
        try {
            GestureDescription.StrokeDescription sd = first
                    ? new GestureDescription.StrokeDescription(p, 0, dur, !finishing)
                    : liveStroke.continueStroke(p, 0, dur, !finishing);
            liveStroke = sd;
            liveOutX = endX;
            liveOutY = endY;
            liveBusy = true;
            GestureDescription g = new GestureDescription.Builder().addStroke(sd).build();
            boolean ok = dispatchGesture(g, new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    liveBusy = false;
                    if (!liveActive) return;
                    if (finishing) finishLive(); else pumpLive();
                }

                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    liveBusy = false;
                    finishLive();   // the system dropped our touch, so stop cleanly
                }
            }, h);
            if (!ok) {
                liveBusy = false;
                finishLive();
                toast("Couldn't follow your finger");
            }
        } catch (Exception ex) {
            liveBusy = false;
            finishLive();
            toast("Couldn't follow your finger");
        }
    }

    private void finishLive() {
        liveActive = false;
        liveEnded = false;
        liveBusy = false;
        liveStroke = null;
        liveEndAt = SystemClock.uptimeMillis();
        h.removeCallbacks(livePumpRun);
        setTriggerTouchable(true);
        if (trigger != null) trigger.setActive(false);
    }

    /** Red circles: one at the real finger, one at the assisted touch. Separate from the trigger. */
    private void startLiveIndicators() {
        h.removeCallbacks(liveTickRun);
        removeIndicators();
        if (!Store.b(this, "show_touches", true)) return;
        indicators = new TouchIndicatorView(this);
        indicators.setMerged(assistIndicatorsMerged);
        try {
            wm.addView(indicators, overlayParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    FULL_FLAGS | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE));
            h.post(liveTickRun);
        } catch (Exception ex) {
            indicators = null;
        }
    }

    private final Runnable liveTickRun = new Runnable() {
        @Override
        public void run() {
            if (indicators == null) return;
            long now = SystemClock.uptimeMillis();
            boolean live = liveActive;
            indicators.update(live ? new float[]{liveFx, liveFy, liveOutX, liveOutY} : new float[0], now);
            if (live || now - liveEndAt < 600) {
                h.postDelayed(this, 16);
            } else {
                removeIndicators();
            }
        }
    };
}
