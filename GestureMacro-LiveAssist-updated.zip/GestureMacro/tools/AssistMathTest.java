package com.gesturemacro.app;

public class AssistMathTest {
    static int fails = 0, passes = 0;
    static void check(String name, boolean ok) {
        if (ok) passes++; else fails++;
        System.out.println((ok ? "PASS  " : "FAIL  ") + name);
    }
    static boolean near(float a, float b) { return Math.abs(a - b) < 0.01f; }
    static boolean nearPt(float[] p, float x, float y) { return near(p[0], x) && near(p[1], y); }

    public static void main(String[] a) {
        // straight guide: 200 px up
        AssistMath up = AssistMath.fromPoints(new float[]{500, 800, 500, 700, 500, 600}, 20f);
        check("straight guide is usable", up.usable());
        check("guide length is 200", near(up.total(), 200f));

        // 3. only responds to real movement
        for (float s : new float[]{0f, 0.5f, 1f})
            check("no finger movement -> no output movement (strength " + s + ")", nearPt(up.offset(0, 0, s), 0, 0));

        // jittery drag up with sideways wobble
        check("strength 1 removes sideways jitter", nearPt(up.offset(7, -100, 1f), 0, -100));
        check("strength 0 follows the finger exactly", nearPt(up.offset(7, -100, 0f), 7, -100));
        check("strength 0.5 is halfway", nearPt(up.offset(8, -100, 0.5f), 4, -100));
        check("user decides how far: 50 px", nearPt(up.offset(3, -50, 1f), 0, -50));
        check("drag past the guide end stops at the end", nearPt(up.offset(2, -500, 1f), 0, -200));
        check("dragging the wrong way does not move the touch", nearPt(up.offset(0, 120, 1f), 0, 0));

        // curved guide: 100 right then 100 up (chord is diagonal)
        AssistMath l = AssistMath.fromPoints(new float[]{100, 500, 200, 500, 200, 400}, 20f);
        float[] mid = l.offset(50f, -50f, 1f);              // half-way along the chord (length 70.7 of 141.4)
        check("curved guide: halfway = end of first leg", nearPt(mid, 100, 0));
        float[] end = l.offset(200, -200, 1f);
        check("curved guide: full drag = end of the guide", nearPt(end, 100, -100));

        // tap-like guide has no direction -> pass the finger through unchanged
        AssistMath tap = AssistMath.fromPoints(new float[]{300, 300, 301, 300}, 20f);
        check("tap-like guide is not usable", !tap.usable());
        check("unusable guide passes finger through", nearPt(tap.offset(13, -40, 1f), 13, -40));
        AssistMath single = AssistMath.fromPoints(new float[]{300, 300}, 20f);
        check("single-point guide is not usable", !single.usable());

        // segment length / speed
        check("segment never shorter than 12 ms", AssistMath.segmentMs(1f, 5f) == 12L);
        check("segment never longer than 50 ms", AssistMath.segmentMs(500f, 0.1f) == 50L);
        check("segment ~ distance / speed", AssistMath.segmentMs(30f, 1f) == 30L);
        check("slow/zero speed does not divide by zero", AssistMath.segmentMs(2f, 0f) == 40L);
        check("smooth starts from first sample", near(AssistMath.smooth(0f, 2f), 2f));
        check("smooth blends", near(AssistMath.smooth(1f, 2f), 1.4f));

        System.out.println("\n" + passes + " passed, " + fails + " failed");
        System.exit(fails == 0 ? 0 : 1);
    }
}
