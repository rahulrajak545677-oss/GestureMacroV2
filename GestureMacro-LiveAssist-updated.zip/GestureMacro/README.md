# Gesture Macro (Android)

An Android copy of the iPhone AssistiveTouch "custom gesture" setup shown in the recordings:
a floating button, a double-tap menu, recorded gestures (macros) and red touch circles that merge
into one while the gesture plays.

Everything is plain Android (no third-party libraries). The app is one APK with two parts:
the settings screens (`MainActivity`, `RecorderActivity`) and an Accessibility Service
(`GestureService`) that draws the floating button over other apps and performs the taps and swipes.

> This project was written without an Android SDK, so it has been compile-checked against a stand-in
> API but **never run on a phone yet**. Treat the first build as a test run.

## 1. Get the APK (pick one)

**A. Android Studio (easiest if you have a PC)**
1. Install Android Studio, choose *Open*, select this folder.
2. Wait for the Gradle sync, then *Build > Build APK(s)*.
3. The file is `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone.

**B. GitHub builds it for you (no software to install)**
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder, **including the hidden `.github` folder** (drag the folder in the browser).
3. Open the *Actions* tab, run *Build APK*, then download `GestureMacro-apk` from the finished run.

**C. On the phone itself:** an app such as AndroidIDE can open this folder and build it.

## 2. Install and switch it on (once)

1. Open the APK on your phone and install it (allow "install unknown apps" if asked).
2. Open **Gesture Macro**. The orange banner says it is not switched on. Tap it.
3. Tap *Open Accessibility Settings*, find **Gesture Macro**, switch it **ON**, tap *Allow*.
4. If the switch is greyed out ("Restricted setting"): *Open App Info* > three dots (top right) >
   **Allow restricted settings**, then repeat step 3. (Android 13+ does this for apps installed outside the Play Store.)

The floating button now appears on the right edge of every app.

## 3. The steps from your recordings, one by one

| In the iPhone recordings | In this app |
|---|---|
| Settings > Accessibility > Touch > AssistiveTouch | Open the app: **Touch** page, tap **AssistiveTouch** |
| AssistiveTouch switch, Customize Top Level Menu | Same page: switch + **Customize Top Level Menu** |
| Custom Actions: Single-Tap *None*, Double-Tap *Open Menu*, Long Press *None* | Same rows, same defaults. Each can also run a saved gesture |
| Custom Gestures > Create New Gesture | **Create New Gesture...** opens the black recording canvas |
| Tap or swipe, rotate the phone, timeline, Stop, Play, Save | Same: Cancel / New Gesture / Save on top, timeline + Play / Stop at the bottom (up to 60 s, any number of fingers) |
| Name dialog (Macro, Macro1, Micro 2) | "Gesture name" dialog |
| Edit: red minus, Delete, drag handles, Done | Same, including drag-to-reorder; tapping the red minus reveals Delete |
| Idle Opacity 37% | **Idle Opacity** slider (15-100%) |
| Pointer Devices: Devices, Mouse Keys, Show Onscreen Keyboard, Sound on Click, Always Show Menu, Perform Touch Gestures, Use Game Controller, Tracking Sensitivity, Dwell Control (Fallback Action, Movement Tolerance, Hot Corners, Extended Predictions, 0.25 Second) | All present with the same order and wording |
| Touch page: Reachability ... Call Audio Routing | All present |
| Double-tap the button > menu: Custom, Notification Center, Device, Gestures, Home, Control Center | Same 3x2 menu. Custom page: Pinch and Rotate, Long Press, Double Tap, Hold and Drag, your gestures, dashed "+" slots, Back in the centre |
| Pick a gesture: red circles appear | Red circles appear where each touch of the gesture starts |
| Tap the icon two times: the circles merge into one and the gesture plays | **Double-tap the floating button**: the circles slide together into one, then the gesture plays and a red circle follows it. One tap cancels |

Rotate the phone the same way as when you recorded (a landscape game needs a landscape recording).

## 3b. Live Assist (your finger stays in control)

Live Assist is on by default (AssistiveTouch page > **Live Assist**). Choosing a gesture no longer plays it.

1. Open the menu > Custom > pick a gesture. **One fixed red circle (the trigger)** appears. It never moves.
   First time only, it appears where that gesture starts. Move it later by enabling **Live Assist > Red Trigger & Strength > Move Red Trigger (Setup Mode)**, dragging it, then switching setup mode off before gameplay.
2. **Press the red circle and drag with your own finger.** The app reads your finger (direction, distance,
   speed, duration) and the touch the game sees follows the shape of your saved gesture, as far along it
   as your finger has gone. **Assist Strength** 0% = exactly your finger, 100% = the gesture's shape.
3. Lift your finger and the touch lifts. Nothing is sent when you are not touching the red circle.
4. **Red touch circles** (Show Red Touch Circles): one at your finger, one at the assisted touch. They are
   separate from the trigger. Long-press the floating button to remove the trigger.

Why it works this way: Android does not let an ordinary overlay watch or edit another app's touches.
Only a window that receives a touch can read it, and an accessibility service can only add touches with
`dispatchGesture`. So the trigger is a small window that owns only the touches that start on it; while your
finger is down it stops taking touches and the assisted touch is injected in short chained segments
(`continueStroke`). Limits: a short lag (one segment, roughly 12-50 ms plus system delay), one assisted finger
at a time, and a game may ignore touches that come from an accessibility service.

Turn **Live Assist** off to get the old replay behaviour back (Arm, Then Double-Tap).

Tests: `tools/AssistMathTest.java` checks the assist maths on a PC
(`javac -d out app/src/main/java/com/gesturemacro/app/AssistMath.java tools/AssistMathTest.java && java -cp out com.gesturemacro.app.AssistMathTest`, in package `com.gesturemacro.app`).
The Android parts have NOT been run yet. Try these on a phone (Android 12-15), in this order:

1. Pick a gesture: the red trigger appears. Drag your finger elsewhere on the screen, rotate, open the menu: it does not move.
2. Press the trigger and drag: with **Show Red Touch Circles** on, a red circle is at your finger and one at the assisted touch.
3. Press the trigger and hold still: nothing moves. Release: nothing moves. Do not touch the trigger for a minute: nothing happens.
4. Set Assist Strength to 0%: the touch follows your finger exactly (proves it tracks you). 100%: it follows the gesture shape.
5. Turn **Show Red Touch Circles** off: no circles at all (also none in the old replay).
6. Floating button: single tap, double tap and long press still run their actions; Macro 1 is still in the Custom page.
7. Enable Move Red Trigger (Setup Mode), drag it to the desired location, then disable setup mode. In gameplay mode it stays fixed.
8. Watch for a stuck touch after lifting (the game should see the finger go up), and for crashes.

If step 2 shows the circle at your finger but the game does not react, the game is ignoring touches from accessibility services.
If the assisted circle stops after the very first moment, the system stopped sending your finger once the trigger became
non-touchable. Both are Android/game limits, not something this app can get around.

## 4. What really works, and what is only a copy of the iPhone screen

Works: floating button (drag, edge snap, idle fade), menu, Single/Double/Long-press actions, recording,
saving, renaming, reordering, deleting, replaying gestures, Pinch and Rotate, Long Press, Double Tap,
Hold and Drag, Notification Center, Control Center (quick settings), Home, back, recents, lock screen,
screenshot, volume, power menu, Sound on Click, Vibration, Idle Opacity, Customize Top Level Menu.

Saved but with no effect (Android does not let an app do these): Mouse Keys, Dwell Control and its
sub-settings, Use Game Controller, Show Onscreen Keyboard, Perform Touch Gestures, Always Show Menu,
Tracking Sensitivity, Reachability, Tap to Wake, Shake to Undo, Prevent Lock to End Call,
Call Audio Routing, Haptic Touch, Touch Accommodations.

## 5. Known limits

* A gesture can hold at most 10 fingers at once and 60 seconds (Android limits).
* Recorded speed is approximate: Android replays each swipe at an even speed over its recorded duration.
* Some games ignore touches injected by accessibility services. If one does, nothing can be done from inside an app.
* Online games may forbid macros in their terms of service. Using one is at your own risk.
